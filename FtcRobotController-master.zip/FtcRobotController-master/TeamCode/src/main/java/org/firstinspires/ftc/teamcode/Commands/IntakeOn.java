package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.IntakeSys;

public class  IntakeOn {
    private final IntakeSys intake;
    public IntakeOn(IntakeSys intake) { this.intake = intake; }
    public void execute() { intake.in(); }
}
