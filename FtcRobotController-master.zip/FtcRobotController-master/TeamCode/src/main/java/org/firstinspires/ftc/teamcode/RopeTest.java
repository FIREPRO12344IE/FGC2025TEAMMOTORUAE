package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;

@TeleOp(name="RopeDriveLauncher_PS5", group="Linear OpMode")
public class RopeTest extends LinearOpMode {

    private DcMotor leftMotor;
    private DcMotor rightMotor;
    private DcMotor ropeMotor;
    private DcMotor launcherA;
    private DcMotor launcherB;
    private DcMotor intake1;
    private DcMotor intake2;
    private DcMotor intake3;

    private Servo servo1;
    private Servo servo2;

    private double launcherPower = 1.0;
    private boolean clawOpen = false;
    private boolean prevSquare = false;

    @Override
    public void runOpMode() {

        leftMotor  = hardwareMap.get(DcMotor.class, "motor1");
        rightMotor = hardwareMap.get(DcMotor.class, "motor2");
        ropeMotor  = hardwareMap.get(DcMotor.class, "motor3");
        launcherA  = hardwareMap.get(DcMotor.class, "motor4");
        launcherB  = hardwareMap.get(DcMotor.class, "motor5");
        intake1    = hardwareMap.get(DcMotor.class, "core1");
        intake2    = hardwareMap.get(DcMotor.class, "core2");
        intake3    = hardwareMap.get(DcMotor.class, "core3");
        servo1 = hardwareMap.get(Servo.class, "servo1");
        servo2 = hardwareMap.get(Servo.class, "servo2");

        rightMotor.setDirection(DcMotor.Direction.REVERSE);
        servo1.setDirection(Servo.Direction.REVERSE);
        launcherA.setDirection(DcMotor.Direction.REVERSE);

        waitForStart();
        while (opModeIsActive()) {

            double drive = gamepad1.right_stick_x;
            double turn  = -gamepad1.left_stick_y;
            double leftPower  = Range.clip(drive + turn, -1.0, 1.0);
            double rightPower = Range.clip(drive - turn, -1.0, 1.0);
            leftMotor.setPower(leftPower);
            rightMotor.setPower(rightPower);

            if (gamepad1.left_trigger > 0.1) {
                ropeMotor.setPower(gamepad1.left_trigger);
            } else if (gamepad1.right_trigger > 0.1) {
                ropeMotor.setPower(-gamepad1.right_trigger);
            } else {
                ropeMotor.setPower(0);
            }

            if (gamepad1.dpad_up) {
                launcherPower = Range.clip(launcherPower + 0.1, 0.0, 1.0);
            }
            if (gamepad1.dpad_down) {
                launcherPower = Range.clip(launcherPower - 0.1, 0.0, 1.0);
            }

            if (gamepad1.cross) {
                launcherA.setPower(launcherPower);
                launcherB.setPower(launcherPower);
            } else if (gamepad1.circle) {
                launcherA.setPower(-launcherPower);
                launcherB.setPower(-launcherPower);
            } else if (gamepad1.triangle) {
                launcherA.setPower(0);
                launcherB.setPower(0);
            }

            boolean currentSquare = gamepad1.square;
            if (currentSquare && !prevSquare) {
                clawOpen = !clawOpen;
            }

            if (clawOpen) {
                servo1.setPosition(-0.3);
                servo2.setPosition(-1.0);
            } else {
                servo1.setPosition(1.0);
                servo2.setPosition(1.0);
            }

            prevSquare = currentSquare;

            if (gamepad1.left_bumper) {
                intake1.setPower(1);
                intake2.setPower(1);
                intake3.setPower(1);
            } else if (gamepad1.right_bumper) {
                intake1.setPower(-1);
                intake2.setPower(-1);
                intake3.setPower(-1);
            } else {
                intake1.setPower(0);
                intake2.setPower(0);
                intake3.setPower(0);
            }

            telemetry.addData("Launcher Power", "%.1f", launcherPower);
            telemetry.addData("Servo1", servo1.getPosition());
            telemetry.addData("Servo2", servo2.getPosition());
            telemetry.update();
        }
    }
}
