package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.RopeSys;

public class RopeIn {
    private final RopeSys rope;
    private double power = 1.0;
    public RopeIn(RopeSys rope) { this.rope = rope; }
    public void setPower(double p) { this.power = Math.max(0, Math.min(1, p)); }
    public void execute() { rope.in(power); }
}
