package org.firstinspires.ftc.teamcode.Subsystems;


import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.Range;

public class LauncherSys {
    private final DcMotor motor4; // launcher A
    private final DcMotor motor5; // launcher B
    private double launcherPower = 1.0;

    public LauncherSys(HardwareMap hw) {
        motor4 = hw.get(DcMotor.class, "motor4");
        motor5 = hw.get(DcMotor.class, "motor5");
        motor4.setDirection(DcMotor.Direction.REVERSE); // matches your old code
    }

    public double getPower() { return launcherPower; }
    public void increasePower() { launcherPower = Range.clip(launcherPower + 0.1, 0.0, 1.0); }
    public void decreasePower() { launcherPower = Range.clip(launcherPower - 0.1, 0.0, 1.0); }

    public void forward() { motor4.setPower(launcherPower); motor5.setPower(launcherPower); }
    public void launchBackward() { motor4.setPower(-launcherPower); motor5.setPower(-launcherPower); }
    public void stop() { motor4.setPower(0); motor5.setPower(0); }
}
