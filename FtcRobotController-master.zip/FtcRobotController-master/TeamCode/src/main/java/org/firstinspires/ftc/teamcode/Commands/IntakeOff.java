package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.IntakeSys;

public class IntakeOff {
    private final IntakeSys intake;
    public IntakeOff(IntakeSys intake) { this.intake = intake; }
    public void execute() { intake.stop(); }
}
