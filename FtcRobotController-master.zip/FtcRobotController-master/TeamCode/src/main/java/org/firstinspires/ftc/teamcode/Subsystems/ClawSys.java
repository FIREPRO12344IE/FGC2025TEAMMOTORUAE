package org.firstinspires.ftc.teamcode.Subsystems;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class ClawSys {
    private final Servo servo1;
    private final Servo servo2;

    public ClawSys(HardwareMap hw) {
        servo1 = hw.get(Servo.class, "servo1");
        servo2 = hw.get(Servo.class, "servo2");
        servo1.setDirection(Servo.Direction.REVERSE); // matches your old code
    }

    public void open()  { servo1.setPosition(-0.3); servo2.setPosition(-1.0); }
    public void close() { servo1.setPosition(1.0);  servo2.setPosition(1.0);  }
}
