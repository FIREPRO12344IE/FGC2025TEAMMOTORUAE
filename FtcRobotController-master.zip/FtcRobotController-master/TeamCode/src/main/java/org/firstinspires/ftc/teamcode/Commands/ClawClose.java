
package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.ClawSys;

public class ClawClose {
    private final ClawSys claw;
    public ClawClose(ClawSys claw) { this.claw = claw; }
    public void execute() { claw.close(); }
}
