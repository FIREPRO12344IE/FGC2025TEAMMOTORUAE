
package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.ClawSys;

public class ClawOpen {
    private final ClawSys claw;
    public ClawOpen(ClawSys claw) { this.claw = claw; }
    public void execute() { claw.open(); }
}
