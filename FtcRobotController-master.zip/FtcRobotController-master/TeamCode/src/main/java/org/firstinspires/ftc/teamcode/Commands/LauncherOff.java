package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.LauncherSys;

public class LauncherOff {
    private final LauncherSys launcher;
    public LauncherOff(LauncherSys launcher) { this.launcher = launcher; }
    public void execute() { launcher.stop(); }
}
