package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.Subsystems.ClawSys;
import org.firstinspires.ftc.teamcode.Subsystems.DrivetrainSys;
import org.firstinspires.ftc.teamcode.Subsystems.IntakeSys;
import org.firstinspires.ftc.teamcode.Subsystems.LauncherSys;
import org.firstinspires.ftc.teamcode.Subsystems.RopeSys;

import org.firstinspires.ftc.teamcode.Commands.ClawOpen;
import org.firstinspires.ftc.teamcode.Commands.ClawClose;
import org.firstinspires.ftc.teamcode.Commands.IntakeOn;
import org.firstinspires.ftc.teamcode.Commands.IntakeOff;
import org.firstinspires.ftc.teamcode.Commands.LauncherOn;
import org.firstinspires.ftc.teamcode.Commands.LauncherOff;
import org.firstinspires.ftc.teamcode.Commands.RopeIn;
import org.firstinspires.ftc.teamcode.Commands.RopeOut;

@TeleOp(name="Mainopmode", group="Linear OpMode")
public class Mainopmode extends OpMode {

    // Subsystems
    private DrivetrainSys drivetrain;
    private RopeSys      ropeSys;
    private LauncherSys  launcherSys;
    private IntakeSys    intakeSys;
    private ClawSys      clawSys;

    // Commands
    private IntakeOn   intakeOnCmd;
    private IntakeOff  intakeOffCmd;
    private LauncherOn launcherOnCmd;
    private LauncherOff launcherOffCmd;
    private RopeIn     ropeInCmd;
    private RopeOut    ropeOutCmd;
    private ClawOpen   clawOpenCmd;
    private ClawClose  clawCloseCmd;

    // State for claw toggle
    private boolean prevSquare = false;
    private boolean clawOpen = false;

    @Override
    public void init() {
        // Build subsystems (each maps its own hardware)
        drivetrain  = new DrivetrainSys(hardwareMap);
        ropeSys     = new RopeSys(hardwareMap);
        launcherSys = new LauncherSys(hardwareMap);
        intakeSys   = new IntakeSys(hardwareMap);
        clawSys     = new ClawSys(hardwareMap);

        // Build commands
        intakeOnCmd    = new IntakeOn(intakeSys);
        intakeOffCmd   = new IntakeOff(intakeSys);
        launcherOnCmd  = new LauncherOn(launcherSys);
        launcherOffCmd = new LauncherOff(launcherSys);
        ropeInCmd      = new RopeIn(ropeSys);
        ropeOutCmd     = new RopeOut(ropeSys);
        clawOpenCmd    = new ClawOpen(clawSys);
        clawCloseCmd   = new ClawClose(clawSys);
    }

    @Override
    public void loop() {
        // ----- DRIVE (same logic you had originally) -----
        double drive = gamepad1.right_stick_x;   // strafe/forward mix you used
        double turn  = -gamepad1.left_stick_y;   // turning
        drivetrain.drive(drive, turn);

        // ----- ROPE (triggers give variable power) -----
        if (gamepad1.left_trigger > 0.1) {
            ropeOutCmd.setPower(gamepad1.left_trigger);
            ropeOutCmd.execute();
        } else if (gamepad1.right_trigger > 0.1) {
            ropeInCmd.setPower(gamepad1.right_trigger);
            ropeInCmd.execute();
        } else {
            ropeSys.stop();
        }

        // ----- LAUNCHER power bump -----
        if (gamepad1.dpad_up)   launcherSys.increasePower();
        if (gamepad1.dpad_down) launcherSys.decreasePower();

        // ----- LAUNCHER run/stop (forward = X, reverse = O, stop = Δ) -----
        if (gamepad1.cross) {
            launcherOnCmd.execute();              // forward at current power
        } else if (gamepad1.circle) {
            launcherSys.launchBackward();         // reverse (direct to subsystem)
        } else if (gamepad1.triangle) {
            launcherOffCmd.execute();             // stop
        }

        // ----- INTAKE (LB = in, RB = stop; you only wanted On/Off) -----
        if (gamepad1.left_bumper) {
            intakeOnCmd.execute();
        } else if (gamepad1.right_bumper) {
            intakeOffCmd.execute();
        } else {
            intakeOffCmd.execute();
        }

        // ----- CLAW toggle on Square -----
        boolean curSquare = gamepad1.square;
        if (curSquare && !prevSquare) {
            clawOpen = !clawOpen;
            if (clawOpen)  clawOpenCmd.execute();   // open = (-0.3, -1.0)
            else           clawCloseCmd.execute();  // close = (1.0, 1.0)
        }
        prevSquare = curSquare;

        // Telemetry
        telemetry.addData("Launcher Power", "%.1f", launcherSys.getPower());
        telemetry.addData("Claw Open", clawOpen);
        telemetry.update();
    }
}
