package org.firstinspires.ftc.teamcode.Subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class IntakeSys {
    private final DcMotor core1;
    private final DcMotor core2;
    private final DcMotor core3;


    public IntakeSys(HardwareMap hw) {
        core1 = hw.get(DcMotor.class, "core1");
        core2 = hw.get(DcMotor.class, "core2");
        core3 = hw.get(DcMotor.class, "core3");

    }

    public void in()   { core1.setPower(1);  core2.setPower(1);  core3.setPower(1); }
    public void out()  { core1.setPower(-1); core2.setPower(-1); core3.setPower(-1); }
    public void stop() { core1.setPower(0);  core2.setPower(0);  core3.setPower(0); }
}
