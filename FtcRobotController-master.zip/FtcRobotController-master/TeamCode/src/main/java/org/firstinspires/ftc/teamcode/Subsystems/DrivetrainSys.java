package org.firstinspires.ftc.teamcode.Subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.Range;

public class DrivetrainSys {
    private final DcMotor leftMotor;   // motor1
    private final DcMotor rightMotor;  // motor2

    public DrivetrainSys(HardwareMap hw) {
        leftMotor  = hw.get(DcMotor.class, "motor1");
        rightMotor = hw.get(DcMotor.class, "motor2");
        rightMotor.setDirection(DcMotor.Direction.REVERSE);
    }

    // Same math you used: left = drive + turn, right = drive - turn
    public void drive(double drive, double turn) {
        double leftPower  = Range.clip(drive + turn, -1.0, 1.0);
        double rightPower = Range.clip(drive - turn, -1.0, 1.0);
        leftMotor.setPower(leftPower);
        rightMotor.setPower(rightPower);
    }
}
