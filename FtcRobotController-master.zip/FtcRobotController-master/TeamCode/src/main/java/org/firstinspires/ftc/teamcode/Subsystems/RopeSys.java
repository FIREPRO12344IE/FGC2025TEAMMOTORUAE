package org.firstinspires.ftc.teamcode.Subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class RopeSys {
    private final DcMotor ropeMotor; // motor3

    public RopeSys(HardwareMap hw) {
        ropeMotor = hw.get(DcMotor.class, "motor3");
    }

    public void out(double power) { ropeMotor.setPower(power); }        // rope out
    public void in(double power)  { ropeMotor.setPower(-power); }       // rope in
    public void stop()            { ropeMotor.setPower(0); }
}
