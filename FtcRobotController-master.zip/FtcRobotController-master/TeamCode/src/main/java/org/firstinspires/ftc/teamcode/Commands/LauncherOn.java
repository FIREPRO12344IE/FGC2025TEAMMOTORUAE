package org.firstinspires.ftc.teamcode.Commands;

import org.firstinspires.ftc.teamcode.Subsystems.LauncherSys;

public class LauncherOn {
    private final LauncherSys launcher;
    public LauncherOn(LauncherSys launcher) { this.launcher = launcher; }
    public void execute() { launcher.forward(); }
}
